<h2>Hey, It's me {{ $data->nombre }}</h2> 
<br>
    
<strong>User details: </strong><br>
<strong>Nombre: </strong>{{ $data->nombre }} <br>
<strong>Email: </strong>{{ $data->email }} <br>
<strong>Teléfono: </strong>{{ $data->telefono }} <br>
<strong>Asunto: </strong>{{ $data->asunto }} <br>
<strong>Mensaje: </strong>{{ $data->user_query }} <br><br>
  
Gracias