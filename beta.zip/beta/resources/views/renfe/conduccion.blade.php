@extends('plantillas.publica')

@section('contenido')
<h1 class="m-0 py-3 text-center bg-RENFE">CONDUCCIÓN</h1>
<div class="container-fluid fondo conduccion">
    <div class="row">
        <div class="col-12">

        </div>
    </div>
</div>
@endsection