<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="keywords" content="sindicato sector federal ferroviario renfe adif anarcosindicalismo trabajadores derechos">
        <meta name="description" content="Sector Federal Ferroviario - CGT"
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="author" content="Sector Federal Ferroviario - CGT">

        <title><?php echo e(config('app.name', 'CGT Ferroviario')); ?></title>

        <!-- Estilos -->
        <?php echo $__env->make('parciales.estilo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </head>
    <body class="antialiased">

        <div class="h-100">
            <?php echo $__env->make('parciales.barrasuperior', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Page Content -->
            <main class="">
                
                        
                

                


                <?php echo $__env->make('parciales.barralateral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <div class="pt-20 sm:ml-52">
                    <!-- Page Heading -->
                    <?php if(isset($header)): ?>
                        <header class="bg-red-500 shadow">
                            <div class="max-w-7xl mx-auto py-3 px-2 sm:px-3 lg:px-4 text-center">
                                <?php echo e($header); ?>

                            </div>
                        </header>
                    <?php endif; ?>
                    <?php echo e($slot); ?>

                    <?php echo $__env->yieldContent('contenido'); ?>
                </div>
            </main>
        </div>

        <?php echo $__env->make('parciales.pie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('parciales.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
</html><?php /**PATH /home/pablo/dev/CGT/beta/resources/views/layouts/privado.blade.php ENDPATH**/ ?>