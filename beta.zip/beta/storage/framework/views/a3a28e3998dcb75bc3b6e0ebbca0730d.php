<?php if (isset($component)) { $__componentOriginalb24087bed3a0ecb8908d744d7af241a3 = $component; } ?>
<?php $component = App\View\Components\PrivadoLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('privado-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PrivadoLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-900 leading-tight">
            <?php echo e(__('Añadir Comunicados')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php $__env->startSection('contenido'); ?>
    <div class="p-8 fondo comunicados">
        <div class="bg-blanco-transp bordeRojo rounded-lg p-4">
            <div class="grid grid-cols-3 mt-2 mb-3">
                <div class="col-span-3">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mensaje','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mensaje'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <div class="sm:flex sm:items-center sm:justify-start">
                    <div class="inline-flex overflow-hidden text-white divide-x rounded-lg rtl:flex-row-reverse">
                        <button class="px-3 py-2 text-xs font-medium text-black transition-colors duration-200 bg-red-500 sm:text-sm">
                            Todos
                        </button>
                        <button class="px-3 py-2 text-xs font-medium bg-oscuro transition-colors duration-200 sm:text-sm hover:bg-red-500 hover:text-gray-900">
                            Por empresa
                        </button>
                        <button class="px-3 py-2 text-xs font-medium bg-oscuro transition-colors duration-200 sm:text-sm hover:bg-red-500 hover:text-black">
                            Por categoría
                        </button>
                    </div>
                </div>
                <div class="sm:flex-row sm:items-center sm:justify-between">
                    <div class="flex items-center gap-x-3">
                        <h2 class="text-lg font-bold text-gray-800">Comunicados</h2>
                        <span class="px-3 py-1 text-xs text-red-600 bg-red-200 rounded-full"><?php echo e($comunicados->count()); ?></span>
                        <p class="mt-1 text-sm text-gray-500">Estos son los comunicados que llevamos este año.</p>
                    </div>
                    
                </div>
                <div class="sm:flex sm:items-center sm:justify-end">
                    <div class="flex items-center gap-x-3 align-middle">
                        <button class="flex items-center justify-center w-1/2 px-2 py-2 text-sm text-gray-100 transition-colors duration-200 bg-oscuro border rounded-lg gap-x-2 sm:w-auto hover:bg-green-500 hover:text-gray-100" title="Importar datos desde un archivo .csv">
                            <i class="lni lni-upload"></i>
                            <span>Importar CSV</span>
                        </button>
                        <button class="flex items-center justify-center w-1/2 px-2 py-2 text-sm text-gray-900 transition-colors duration-200 bg-rojoBrillante bordeNegro rounded-lg gap-x-2 sm:w-auto hover:bg-gray-900 hover:text-red-500" title="Añadir un nuevo comunicado">
                            <i class="lni lni-add-files"></i>
                            <a href="<?php echo e(route('intranet.comunicados.create')); ?>" class="">Añadir comunicado</a>
                        </button>
                    </div>
                </div>
            </div> 
            
            <form class="needs-validation" novalidate="" action="<?php echo e(route('intranet.comunicados.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row g-3">
                    <div class="col-md-3">
                        <label for="country" class="form-label">Empresa</label>
                        <select class="form-select" id="empresa" name="empresa" required="">
                                <option value="Elige empresa">Elige empresa</option>
                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback">
                            Por favor, introduce un empresa.
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="categorias_comunicado" class="form-label">Categoría</label>
                        <select class="form-select" id="categoria" name="categoria" required="">
                            <option value="Elige categoria">Elige Categoría</option>
                            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback">
                            Por favor, introduce un categoría.
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="country" class="form-label">Etiqueta</label>
                        <select class="form-select" id="etiqueta" name="etiqueta" required="">
                            <option value="Elige etiqueta">Elige etiqueta</option>
                            <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($etiqueta->id); ?>"><?php echo e($etiqueta->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback">
                            Por favor, introduce una etiqueta.
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="fecha_com" class="form-label">Fecha</label>
                        <input type="date" class="form-control rojoBrillante" name="fecha" placeholder="<?php echo date("Y/m/d"); ?>">
                        <div class="invalid-feedback">
                            Por favor, introduce un fecha.
                        </div>
                    </div>
                    <div class="col-md-2">
                        <label for="country" class="form-label">Número</label>
                        <input type="number" class="form-control" id="numero" name="numero" placeholder="" value="" required="">
                        <div class="invalid-feedback">
                            Por favor, introduce un número de comunicado.
                        </div>
                    </div>
                    <div class="col-sm-5">
                        <label for="titulo" class="form-label">Título</label>
                        <input type="text" class="form-control" id="titulo" name="titulo" placeholder="" value="" required="">
                        <div class="invalid-feedback">
                            Por favor, introduce un título de comunicado.
                        </div>
                    </div>
                    
                    <div class="col-sm-5">
                        <label for="lastName" class="form-label">Subtitulo</label>
                        <input type="text" class="form-control" id="subtitulo" name="subtitulo" placeholder="" value="" required="">
                        <div class="invalid-feedback">
                            Por favor, introduce un subtítulo de comunicado.
                        </div>
                    </div>
    
                    <div class="col-12">
                        <label for="username" class="form-label">Descripción</label>
                        <textarea name="cuerpo" class="form-control" id="cuerpo" cols="30" rows="10"></textarea>
                        <div class="invalid-feedback">
                            Por favor, introduce un cuerpo de comunicado.
                        </div>
                    </div>
    
                    <div class="col-12">
                        <label for="email" class="form-label">Comunicado en PDF</label>
                        <input type="text" name="adjunto1" class="form-control" id="doc_pdf">
                        <div class="invalid-feedback">
                            Por favor, revisa el archivo en pdf del comunicado.
                        </div>
                    </div>
    
                    <div class="col-12">
                        <label for="address" class="form-label">Adjuntos (anexos)</label>
                        <input type="text"  name="adjunto2" class="form-control" id="doc_adj">
                        <div class="invalid-feedback">
                            Please enter your shipping address.
                        </div>
                    </div>
    
                    <div class="col-12">
                        <label for="address2" class="form-label">Imagen (jpg o png)</label>
                        <input type="text" name="adjunto3" class="form-control" id="doc_img">
                        <div class="invalid-feedback">
                            Por favor, introduce una imagen de comunicado.
                        </div>
                    </div>

                    <div class="col-12">
                        <label for="address2" class="form-label">Imagen (jpg o png)</label>
                        <input type="text" name="imagen" class="form-control" id="doc_img">
                        <div class="invalid-feedback">
                            Por favor, introduce una imagen de comunicado.
                        </div>
                    </div>
                    <div class="col-12">
                        
                        <label class="switch">
                            <input type="checkbox" name="publicado" class="form-control" id="publicado" checked >
                            <span class="slider round"></span>
                        </label>
                        <label for="address2" class="form-label align-bottom">Publicado</label>
                        <div class="invalid-feedback">
                            Por favor, introduce una imagen de comunicado.
                        </div>
                    </div>
                </div>
                <hr class="my-4">
    
                <button class="w-100 btn btn-outline-danger btn-lg" type="submit">Subir Comunicado</button>
            </form>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb24087bed3a0ecb8908d744d7af241a3)): ?>
<?php $component = $__componentOriginalb24087bed3a0ecb8908d744d7af241a3; ?>
<?php unset($__componentOriginalb24087bed3a0ecb8908d744d7af241a3); ?>
<?php endif; ?><?php /**PATH /home/pablo/dev/CGT/beta/resources/views/intranet/comunicados/create.blade.php ENDPATH**/ ?>