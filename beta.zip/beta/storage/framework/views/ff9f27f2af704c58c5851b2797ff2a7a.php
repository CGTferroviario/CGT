<img src="/img/logo_med.png" alt="" class="img-fluid">
<?php /**PATH /home/pablo/dev/CGT/beta/resources/views/components/application-logo.blade.php ENDPATH**/ ?>