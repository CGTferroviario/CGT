
<link href="<?php echo e(asset('css/normalize.css')); ?>" rel="stylesheet">

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.bunny.net">
<link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />


<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,900;1,400;1,500;1,900&display=swap" rel="stylesheet">
<link href="http://fonts.cdnfonts.com/css/brannboll-connect-personal-use" rel="stylesheet">


<link rel="stylesheet" href="https://cdn.lineicons.com/4.0/lineicons.css" />


<link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">



<link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.6/flowbite.min.css" rel="stylesheet" />

<?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

<link id="hojaEstilo" href="<?php echo e(asset('css/cgtferroviario.css')); ?>" rel="stylesheet">

<?php /**PATH /home/pablo/dev/CGT/beta/resources/views/parciales/estilo.blade.php ENDPATH**/ ?>