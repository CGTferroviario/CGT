<footer class="py-10 px-1 bg-oscuro">
  <div class="w-full">
    <div class="w-full px-4 text-center text-red-500">
      <span>Avda. Ciudad de Barcelona 10 - Sótano // 28007 Madrid</span><br>
      <span>Tfnos: 91 506 62 85 // 91 506 62 87 // Fax: 91 506 63 14 // <a href="mailto:sff-cgt@cgt.es" title="Correo Electrónico">sff-cgt@cgt.es</a></span><br>
      <span>Creado por <a href="/">CGT Ferroviario</a> &middot; &copy; <?php echo e(date('Y')); ?></span>
    </div>
  </div>
</footer><?php /**PATH /home/pablo/dev/CGT/beta/resources/views/parciales/pie.blade.php ENDPATH**/ ?>