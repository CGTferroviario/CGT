<?php if (isset($component)) { $__componentOriginalb24087bed3a0ecb8908d744d7af241a3 = $component; } ?>
<?php $component = App\View\Components\PrivadoLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('privado-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PrivadoLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-900 leading-tight">
            <?php echo e(__('Comunicados')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php $__env->startSection('contenido'); ?>
    <div class="p-8 fondo comunicados">
        <div class="bg-blanco-transp bordeRojo rounded-lg p-4">
            <div class="grid grid-cols-3 mt-2 mb-3">
                <div class="col-span-3">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mensaje','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mensaje'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
                <div class="sm:flex sm:items-center sm:justify-start">
                    <div class="inline-flex overflow-hidden text-white divide-x rounded-lg rtl:flex-row-reverse">
                        <button class="px-3 py-2 text-xs font-medium text-black transition-colors duration-200 bg-red-500 sm:text-sm">
                            Todos
                        </button>
                        <button class="px-3 py-2 text-xs font-medium bg-oscuro transition-colors duration-200 sm:text-sm hover:bg-red-500 hover:text-gray-900">
                            Por empresa
                        </button>
                        <button class="px-3 py-2 text-xs font-medium bg-oscuro transition-colors duration-200 sm:text-sm hover:bg-red-500 hover:text-black">
                            Por categoría
                        </button>
                    </div>
                </div>
                <div class="sm:flex-row sm:items-center sm:justify-between">
                    <div class="flex items-center gap-x-3">
                        <h2 class="text-lg font-bold text-gray-800">Comunicados</h2>
                        <span class="px-3 py-1 text-xs text-red-600 bg-red-200 rounded-full"><?php echo e($comunicados->count()); ?></span>
                        <p class="mt-1 text-sm text-gray-500">Estos son los comunicados que llevamos este año.</p>
                    </div>
                    
                </div>
                <div class="sm:flex sm:items-center sm:justify-end">
                    <div class="flex items-center gap-x-3 align-middle">
                        <button class="flex items-center justify-center w-1/2 px-2 py-2 text-sm text-gray-100 transition-colors duration-200 bg-oscuro border rounded-lg gap-x-2 sm:w-auto hover:bg-green-500 hover:text-gray-100" title="Importar datos desde un archivo .csv">
                            <i class="lni lni-upload"></i>
                            <span>Importar CSV</span>
                        </button>
                        <button class="flex items-center justify-center w-1/2 px-2 py-2 text-sm text-gray-900 transition-colors duration-200 bg-rojoBrillante bordeNegro rounded-lg gap-x-2 sm:w-auto hover:bg-gray-900 hover:text-red-500" title="Añadir un nuevo comunicado">
                            <i class="lni lni-add-files"></i>
                            <a href="<?php echo e(route('intranet.comunicados.create')); ?>" class="">Añadir comunicado</a>
                        </button>
                    </div>
                </div>
            </div> 
            <table id="comunicadosAdmin" class="display nowrap text-sm pt-5 font-normal rounded-t-lg" style="width:100%">
                <thead class="rounded-t-lg bg-black text-white">
                    <tr>
                        <th class="rounded-tl-lg">Nº</th>
                        <th>Acciones</th>
                        <th>Fecha</th>
                        <th title="Visualizaciones">Vis.</th>
                        <th title="Autor">Autor</th>
                        <th>Título</th>
                        <th>Empresa</th>                        
                        <th>Categorías</th>
                        <th class="rounded-tr-lg">Etiquetas</th>
                        <th>Subtítulo</th>
                        <th>Cuerpo</th>
                        <th>Adjunto 1</th>
                        <th>Adjunto 2</th>
                        <th>Adjunto 3</th>
                        <th>Imagen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $comunicados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comunicado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($comunicado->numero); ?></td>
                        <td>
                            <div class="flex justify-start gap-1 text-xl mt-2">
                                <a x-data="{ tooltip: 'Enviar' }" href="<?php echo e(url('comunicados.edit', $comunicado->id)); ?>"
                                    class="text-blue-500 hover:bg-blue-500 hover:text-white p-1 rounded-lg h-8" title="Enviar por correo">
                                    <i class="lni lni-envelope"></i>
                                </a> 
                                <a x-data="{ tooltip: 'Edite' }" href="<?php echo e(url('comunicados.edit', $comunicado->id)); ?>"
                                    class="text-green-500 hover:bg-green-500 hover:text-white p-1 rounded-lg h-8" title="Editar Comunicado">
                                    <i class="lni lni-pencil"></i>
                                </a>                                
                                <form method="POST" action="<?php echo e(route('intranet.comunicados.destroy', $comunicado->id)); ?>" onsubmit="return confirm('¿Deseas eliminar este comunicado?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class=" p-1 rounded-md">
                                        <a x-data="{ tooltip: 'Delete' }" href="#" title="Eliminar Comunicado" class="text-red-500 hover:bg-red-500 hover:text-white p-1 rounded-lg h-8">
                                            <i class="lni lni-trash-can"></i>
                                        </a>
                                    </button>
                                </form>                                
                            </div>
                        </td>
                        <td><?php echo e($comunicado->fecha); ?></td>
                        <td><?php echo e($comunicado->visualizaciones); ?></td>
                        <td><?php echo e($comunicado->user->nombre); ?></td>
                        <td><?php echo e($comunicado->titulo); ?></td>
                        <td><span class="px-3 py-1 text-sm font-semibold rounded-full bg-<?php echo e($comunicado->empresa?->nombre); ?>"><?php echo e($comunicado->empresa?->nombre); ?></span></td>
                        <td><span class="px-3 py-1 text-sm font-semibold rounded-full bg-<?php echo e($comunicado->categoria?->nombre); ?>"><?php echo e($comunicado->categoria?->nombre); ?></span></td>
                        <td><?php echo e($comunicado->etiqueta->nombre); ?></td>
                        <td><?php echo e($comunicado->subtitulo); ?></td>
                        <td><?php echo nl2br(e($comunicado->cuerpo)); ?></td>
                        
                        <td><?php echo e($comunicado->adjunto1); ?> 1</td>
                        <td><?php echo e($comunicado->adjunto2); ?> 2</td>
                        <td><?php echo e($comunicado->adjunto3); ?> 3</td>
                        <td><?php echo e($comunicado->imagen); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb24087bed3a0ecb8908d744d7af241a3)): ?>
<?php $component = $__componentOriginalb24087bed3a0ecb8908d744d7af241a3; ?>
<?php unset($__componentOriginalb24087bed3a0ecb8908d744d7af241a3); ?>
<?php endif; ?><?php /**PATH /home/pablo/dev/CGT/beta/resources/views/intranet/comunicados/index.blade.php ENDPATH**/ ?>